# -*- coding: utf-8 -*-
__author__ = "Marten4n6"
__license__ = "GPLv3"


def run(options):
    # Simply swap out the old encrypted payload with the new one
    # then reload the launch daemon.
    pass
