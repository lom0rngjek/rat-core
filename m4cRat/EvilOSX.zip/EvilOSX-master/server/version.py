# -*- coding: utf-8 -*-
"""Keeps track of the current server version.

See https://semver.org
"""
__author__ = "Marten4n6"
__license__ = "GPLv3"

VERSION = "7.2.1"
